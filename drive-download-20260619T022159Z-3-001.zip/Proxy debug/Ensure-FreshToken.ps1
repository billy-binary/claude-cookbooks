# =============================================================================
# TOKEN REFRESH SCRIPT FOR LOCAL TERRAFORM RUNS
# =============================================================================
# Purpose: Ensure your service principal token is fresh before Terraform operations
# Run this BEFORE: terraform plan / terraform apply
#
# How it works:
#   1. Gets SP credentials from Key Vault
#   2. Checks when token was last refreshed
#   3. If token is older than threshold (default 30 min), refreshes it
#   4. Updates token in Key Vault (creates audit trail)
#   5. Sets environment variables for Terraform to use
#
# Usage:
#   .\Ensure-FreshToken.ps1 -KeyVaultName "your-keyvault"
#   (Run before: terraform plan)
#
# Compliant because:
#   - All operations logged in Key Vault audit logs
#   - Service principal auth to Azure AD is logged
#   - Token refresh timestamps stored in Key Vault
#   - Works through proxy (standard Azure AD endpoint)
# =============================================================================

param(
    [Parameter(Mandatory = $true)]
    [string]$KeyVaultName,
    
    [Parameter(Mandatory = $false)]
    [string]$TenantId,
    
    [Parameter(Mandatory = $false)]
    [int]$RefreshThresholdMinutes = 30,
    
    [switch]$Verbose = $false
)

# Setup
$ErrorActionPreference = "Stop"
$WarningPreference = "SilentlyContinue"

# Colors for output
$colors = @{
    success = "Green"
    warning = "Yellow"
    error   = "Red"
    info    = "Cyan"
    debug   = "Gray"
}

# =============================================================================
# HELPER FUNCTIONS
# =============================================================================

function Write-Status {
    param([string]$Message, [string]$Level = "info")
    
    $symbol = @{
        success = "✓"
        warning = "⚠"
        error   = "✗"
        info    = "→"
        debug   = "•"
    }[$Level]
    
    Write-Host "  $symbol $Message" -ForegroundColor $colors[$Level]
}

function Write-Section {
    param([string]$Title)
    Write-Host "`n$Title" -ForegroundColor $colors["info"]
    Write-Host ("=" * $Title.Length) -ForegroundColor $colors["info"]
}

function Invoke-TokenRequest {
    param(
        [string]$ClientId,
        [string]$ClientSecret,
        [string]$TenantId,
        [string]$Resource = "https://management.azure.com"
    )
    
    $body = @{
        grant_type    = "client_credentials"
        client_id     = $ClientId
        client_secret = $ClientSecret
        resource      = $Resource
    }
    
    try {
        Write-Status "Requesting access token from Azure AD..." "debug"
        
        $response = Invoke-RestMethod `
            -Uri "https://login.microsoftonline.com/$TenantId/oauth2/token" `
            -Method POST `
            -Body $body `
            -ContentType "application/x-www-form-urlencoded" `
            -ErrorAction Stop
        
        return @{
            AccessToken  = $response.access_token
            ExpiresIn    = $response.expires_in
            TokenType    = $response.token_type
            Success      = $true
            ErrorMessage = $null
        }
    }
    catch {
        return @{
            AccessToken  = $null
            ExpiresIn    = 0
            TokenType    = $null
            Success      = $false
            ErrorMessage = $_.Exception.Message
        }
    }
}

# =============================================================================
# MAIN LOGIC
# =============================================================================

Write-Host "`n" + ("=" * 60) -ForegroundColor $colors["info"]
Write-Host "SERVICE PRINCIPAL TOKEN REFRESH FOR LOCAL TERRAFORM" -ForegroundColor $colors["info"]
Write-Host ("=" * 60) -ForegroundColor $colors["info"]

try {
    # Step 1: Authenticate to Azure (if not already authenticated)
    Write-Section "[1/5] Verifying Azure authentication"
    
    $currentContext = $null
    try {
        $currentContext = Get-AzContext -ErrorAction SilentlyContinue
    }
    catch {
        # Not authenticated yet
    }
    
    if (-not $currentContext) {
        Write-Status "Not authenticated. Attempting to authenticate..." "warning"
        Connect-AzAccount -ErrorAction Stop | Out-Null
        Write-Status "Authenticated to Azure" "success"
    } else {
        Write-Status "Already authenticated as: $($currentContext.Account.Id)" "success"
    }
    
    # Step 2: Retrieve service principal credentials from Key Vault
    Write-Section "[2/5] Retrieving service principal credentials from Key Vault"
    
    Write-Status "Accessing Key Vault: $KeyVaultName" "debug"
    
    try {
        $clientIdSecret = Get-AzKeyVaultSecret -VaultName $KeyVaultName -Name "Terraform-SP-ClientId" -ErrorAction Stop
        $clientSecretSecret = Get-AzKeyVaultSecret -VaultName $KeyVaultName -Name "Terraform-SP-ClientSecret" -ErrorAction Stop
        $tenantIdSecret = Get-AzKeyVaultSecret -VaultName $KeyVaultName -Name "Terraform-SP-TenantId" -ErrorAction Stop
        $refreshTimeSecret = Get-AzKeyVaultSecret -VaultName $KeyVaultName -Name "Terraform-SP-TokenRefreshTime" -ErrorAction SilentlyContinue
        
        $clientId = $clientIdSecret.SecretValueText
        $clientSecret = $clientSecretSecret.SecretValueText
        $tenantIdFromKv = $tenantIdSecret.SecretValueText
        $lastRefreshTime = if ($refreshTimeSecret) { $refreshTimeSecret.SecretValueText } else { (Get-Date).AddYears(-1).ToString() }
        
        # Use provided TenantId or get from Key Vault
        if (-not $TenantId) {
            $TenantId = $tenantIdFromKv
        }
        
        Write-Status "Retrieved credentials from Key Vault" "success"
        Write-Status "Client ID: $($clientId.Substring(0, 8))..." "debug"
        Write-Status "Tenant ID: $TenantId" "debug"
    }
    catch {
        Write-Status "Failed to retrieve credentials from Key Vault" "error"
        throw "Key Vault error: $_"
    }
    
    # Step 3: Check token age and determine if refresh is needed
    Write-Section "[3/5] Checking token refresh status"
    
    try {
        $lastRefresh = [DateTime]::Parse($lastRefreshTime)
        $timeSinceRefresh = (Get-Date) - $lastRefresh
        $minutesSinceRefresh = [Math]::Round($timeSinceRefresh.TotalMinutes, 2)
        
        Write-Status "Last refresh: $lastRefresh" "debug"
        Write-Status "Minutes since refresh: $minutesSinceRefresh" "debug"
        Write-Status "Refresh threshold: $RefreshThresholdMinutes minutes" "debug"
        
        if ($minutesSinceRefresh -lt $RefreshThresholdMinutes) {
            Write-Status "Token is fresh - no refresh needed" "success"
            
            # Still export for Terraform use
            Write-Section "[4/5] Exporting existing token for Terraform"
            
            try {
                $tokenSecret = Get-AzKeyVaultSecret -VaultName $KeyVaultName -Name "Terraform-SP-AccessToken" -ErrorAction Stop
                $token = $tokenSecret.SecretValueText
                
                if ($token -and $token -ne "placeholder") {
                    # Set environment variable for Terraform to use
                    $env:AZURE_CLIENT_ID = $clientId
                    $env:AZURE_CLIENT_SECRET = $clientSecret
                    $env:AZURE_TENANT_ID = $TenantId
                    $env:AZURE_SUBSCRIPTION_ID = (Get-AzContext).Subscription.Id
                    
                    Write-Status "Token exported for Terraform use" "success"
                    Write-Status "Environment variables set:" "debug"
                    Write-Status "  AZURE_CLIENT_ID = $($clientId.Substring(0, 8))..." "debug"
                    Write-Status "  AZURE_TENANT_ID = $TenantId" "debug"
                }
            }
            catch {
                Write-Status "Could not export token: $_" "warning"
            }
            
            Write-Host "`n✓ Token refresh check complete - ready for Terraform`n" -ForegroundColor Green
            exit 0
        }
        
        Write-Status "Token is stale - refreshing now..." "warning"
    }
    catch {
        Write-Status "Error checking token age: $_" "error"
        throw $_
    }
    
    # Step 4: Request fresh token
    Write-Section "[4/5] Requesting fresh access token"
    
    $tokenResponse = Invoke-TokenRequest `
        -ClientId $clientId `
        -ClientSecret $clientSecret `
        -TenantId $TenantId
    
    if (-not $tokenResponse.Success) {
        Write-Status "Failed to obtain token: $($tokenResponse.ErrorMessage)" "error"
        throw "Token request failed"
    }
    
    $newAccessToken = $tokenResponse.AccessToken
    $expiresInMinutes = $tokenResponse.ExpiresIn / 60
    
    Write-Status "Access token obtained" "success"
    Write-Status "Token expires in: $([Math]::Round($expiresInMinutes, 2)) minutes" "debug"
    Write-Status "Token preview: $($newAccessToken.Substring(0, 20))..." "debug"
    
    # Step 5: Store refreshed token in Key Vault (creates audit trail)
    Write-Section "[5/5] Storing refreshed token in Key Vault (audit logged)"
    
    try {
        # Update access token
        Write-Status "Updating access token in Key Vault..." "debug"
        Set-AzKeyVaultSecret `
            -VaultName $KeyVaultName `
            -Name "Terraform-SP-AccessToken" `
            -SecretValue (ConvertTo-SecureString $newAccessToken -AsPlainText -Force) `
            -ErrorAction Stop | Out-Null
        
        Write-Status "Access token updated" "success"
        
        # Update refresh timestamp
        Write-Status "Updating refresh timestamp..." "debug"
        Set-AzKeyVaultSecret `
            -VaultName $KeyVaultName `
            -Name "Terraform-SP-TokenRefreshTime" `
            -SecretValue (ConvertTo-SecureString (Get-Date).ToString() -AsPlainText -Force) `
            -ErrorAction Stop | Out-Null
        
        Write-Status "Refresh timestamp updated" "success"
        Write-Status "All operations logged in Key Vault audit" "info"
    }
    catch {
        Write-Status "Failed to store token in Key Vault: $_" "error"
        throw $_
    }
    
    # Export environment variables for Terraform
    Write-Status "Exporting environment variables for Terraform..." "debug"
    
    $env:AZURE_CLIENT_ID = $clientId
    $env:AZURE_CLIENT_SECRET = $clientSecret
    $env:AZURE_TENANT_ID = $TenantId
    $env:AZURE_SUBSCRIPTION_ID = (Get-AzContext).Subscription.Id
    
    Write-Status "Environment variables configured:" "success"
    Write-Status "  AZURE_CLIENT_ID" "debug"
    Write-Status "  AZURE_CLIENT_SECRET" "debug"
    Write-Status "  AZURE_TENANT_ID" "debug"
    Write-Status "  AZURE_SUBSCRIPTION_ID" "debug"
    
    # Success message
    Write-Host "`n" + ("=" * 60) -ForegroundColor Green
    Write-Host "✓ TOKEN REFRESH COMPLETE" -ForegroundColor Green
    Write-Host ("=" * 60) -ForegroundColor Green
    Write-Host "`nYou can now run: terraform plan / terraform apply`n" -ForegroundColor Green
}
catch {
    Write-Host "`n" + ("=" * 60) -ForegroundColor Red
    Write-Host "✗ TOKEN REFRESH FAILED" -ForegroundColor Red
    Write-Host ("=" * 60) -ForegroundColor Red
    Write-Host "`nError: $($_.Exception.Message)`n" -ForegroundColor Red
    
    exit 1
}
