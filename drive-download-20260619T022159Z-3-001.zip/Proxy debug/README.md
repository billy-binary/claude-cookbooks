# Terraform: Token Refresh & Audit Solution for Local Runs

Complete infrastructure-as-code solution for running Terraform locally with automatic token refresh and compliance auditing.

## Problem Statement

You want to:
- Run Terraform from your workstation (not just pipelines)
- Use a service principal with automatic token refresh
- Maintain full audit trail for compliance (SOX5)
- Avoid token expiration issues mid-operation
- Work through your proxy without special permissions

This Terraform module solves all of that.

## Architecture

```
┌─────────────────────────────────────────────────────────────┐
│ YOUR WORKSTATION                                            │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  1. Run: Ensure-FreshToken.ps1                            │
│     └─> Checks token age in Key Vault                     │
│     └─> If >30 min old, requests fresh token from Azure AD│
│     └─> Stores token back in Key Vault (audit logged)     │
│                                                             │
│  2. Run: terraform plan / terraform apply                  │
│     └─> Uses fresh token for all operations               │
│     └─> All changes logged in Activity Log                │
│                                                             │
│  3. Optional: Monitor-TokenAudit.ps1                      │
│     └─> Views token refresh history                       │
│     └─> Checks Key Vault audit trail                      │
│     └─> Confirms compliance                               │
│                                                             │
└─────────────────────────────────────────────────────────────┘
                         │
                         │ (through proxy)
                         ▼
┌─────────────────────────────────────────────────────────────┐
│ AZURE (Your Subscription)                                   │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│ ┌─ Service Principal (sp-local-terraform-dev)             │
│ │  ├─ Client ID (stored in Key Vault)                     │
│ │  ├─ Client Secret (stored in Key Vault, 1 year expiry)  │
│ │  └─ RBAC: App Configuration Data Owner                  │
│ │                                                          │
│ ┌─ Key Vault                                              │
│ │  ├─ Secret: Terraform-SP-ClientId                       │
│ │  ├─ Secret: Terraform-SP-ClientSecret                   │
│ │  ├─ Secret: Terraform-SP-TenantId                       │
│ │  ├─ Secret: Terraform-SP-AccessToken (refreshed)        │
│ │  ├─ Secret: Terraform-SP-TokenRefreshTime               │
│ │  └─ Audit Logs: All secret operations logged            │
│ │                                                          │
│ ┌─ Log Analytics Workspace                                │
│ │  ├─ Key Vault diagnostic logs (90 day retention)        │
│ │  ├─ App Configuration diagnostic logs                   │
│ │  └─ Service Principal auth logs (when available)        │
│ │                                                          │
│ ┌─ Activity Log                                           │
│ │  ├─ Service Principal creation/updates                  │
│ │  ├─ RBAC assignments                                    │
│ │  ├─ Key Vault secret operations                         │
│ │  └─ App Configuration data changes                      │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

## Files in This Module

| File | Purpose |
|------|---------|
| `main.tf` | Core infrastructure - creates SP, Key Vault secrets, audit logging |
| `terraform.tfvars.example` | Template for customization (copy to terraform.tfvars) |
| `Ensure-FreshToken.ps1` | Token refresh automation script (run before terraform) |
| `Monitor-TokenAudit.ps1` | Audit monitoring and compliance verification |
| `README.md` | This file |

## Prerequisites

- Azure subscription
- Terraform >= 1.0
- PowerShell 7.0+
- Azure CLI (for initial authentication)
- Existing resources:
  - Resource Group
  - Key Vault
  - App Configuration store
  - (Optional) Log Analytics workspace

## Setup

### Step 1: Prepare Your Environment

```bash
# Create a working directory
mkdir terraform-local-terraform-runs
cd terraform-local-terraform-runs

# Copy the Terraform files
cp terraform-token-refresh/* .

# Create your tfvars file
cp terraform.tfvars.example terraform.tfvars

# Edit terraform.tfvars with your values
nano terraform.tfvars
```

### Step 2: Customize terraform.tfvars

```hcl
resource_group_name = "your-rg-name"
location            = "eastus"
app_config_name     = "your-app-config-name"
key_vault_name      = "your-keyvault-name"
environment         = "dev"
token_refresh_threshold_minutes = 30
enable_audit_logging = true
```

### Step 3: Initialize and Plan

```bash
# Initialize Terraform (downloads Azure provider)
terraform init

# Review what will be created (DO THIS!)
terraform plan

# Important: Verify you see:
#   - azure ad_application
#   - azure ad_service_principal
#   - azure ad_service_principal_password
#   - azure key_vault_secrets (5 secrets)
#   - azure role_assignments (2 roles)
#   - azure log_analytics_workspace (if creating)
#   - azure monitor_diagnostic_settings (2 settings)
```

### Step 4: Apply (Create Service Principal)

```bash
# Create all infrastructure
terraform apply

# When prompted: "Do you want to perform these actions?" -> type: yes

# OUTPUT: You'll see:
#   - service_principal_client_id
#   - service_principal_tenant_id
#   - key_vault_name
#   - setup_instructions
```

### Step 5: Save Outputs

```bash
# Save the outputs to a file (for reference)
terraform output > terraform_output.txt

# The setup_instructions output tells you the next steps
```

### Step 6: Get the Client Secret

The client secret is in Key Vault. You need it for local authentication:

```powershell
# In PowerShell
$secret = Get-AzKeyVaultSecret -VaultName "your-keyvault-name" `
  -Name "Terraform-SP-ClientSecret"
$secret.SecretValueText  # Copy this value
```

Save this securely (or let the script retrieve it).

## Usage

### Before Running Terraform Locally

**Always run the token refresh script first:**

```powershell
# In the directory with Ensure-FreshToken.ps1
.\Ensure-FreshToken.ps1 -KeyVaultName "your-keyvault-name"

# Output:
#   ✓ Checking Azure authentication
#   ✓ Retrieving service principal credentials from Key Vault
#   ✓ Checking token refresh status
#   ✓ Environment variables set
#   ✓ Ready for Terraform

# This script:
#   1. Gets SP credentials from Key Vault
#   2. Checks if token needs refresh
#   3. Requests fresh token if needed (>30 min old)
#   4. Stores token back in Key Vault (creates audit trail)
#   5. Sets environment variables for Terraform to use
```

### Run Your Terraform Commands

After token refresh, run terraform normally:

```bash
# Plan your changes (inspect first!)
terraform plan -out=tfplan

# Apply if plan looks good
terraform apply tfplan

# All operations use fresh token
# All changes logged in Activity Log
```

### Monitor Audit Trail

After your Terraform operations, check the audit trail:

```powershell
# View token refresh history and operations
.\Monitor-TokenAudit.ps1 `
  -KeyVaultName "your-keyvault-name" `
  -ResourceGroupName "your-rg-name" `
  -AppConfigName "your-app-config-name" `
  -HoursBack 24

# Shows:
#   - When token was last refreshed
#   - All Key Vault operations
#   - Service Principal activity
#   - App Configuration changes
#   - Compliance checklist
```

## How Token Refresh Works

### Problem (Without Refresh)

```
9:00 AM  - You authenticate with service principal
           Token obtained, valid for 1 hour
           
10:00 AM - Token expires
           But you don't know it
           
10:15 AM - You try: terraform plan
           Request fails with: 401 Unauthorized
           Token expired (you don't have admin access to refresh)
           
Frustration → Need to manually re-authenticate
```

### Solution (With This Module)

```
9:00 AM  - Run: Ensure-FreshToken.ps1
           Script checks Key Vault
           Token is less than 30 minutes old → use existing
           
10:00 AM - Run: Ensure-FreshToken.ps1 again
           Token is now 60 minutes old (past 30-min threshold)
           Script requests fresh token from Azure AD
           Fresh token stored in Key Vault (audit logged)
           
10:15 AM - Run: terraform plan
           Uses fresh token
           All operations succeed
           
No frustration → Automatic, audited, compliant
```

### Token Lifecycle

```
Created:
  - Service Principal Password resource set to expire in 1 year
  - You can regenerate before expiration using terraform
  
Refreshed:
  - Every time you run Ensure-FreshToken.ps1
  - Only if token is older than 30 minutes (configurable)
  - Stored in Key Vault (encrypted, audited)
  
Used:
  - Set as environment variable for Terraform
  - Included in all API calls to Azure
  - Expires in 1 hour (standard Azure token TTL)
  
Next cycle:
  - Before your next terraform run
  - Check if token is stale (>30 min)
  - Refresh if needed
```

## Audit Trail & Compliance

All operations are logged for compliance:

### What Gets Logged

1. **Service Principal Creation** (one-time)
   - Who: Your user account
   - What: SP created
   - When: Timestamp
   - Where: Azure Activity Log

2. **Token Refresh Operations** (every time you run script)
   - Who: Service Principal
   - What: Token request to Azure AD
   - When: Timestamp
   - Where: Azure AD Sign-in Logs

3. **Key Vault Operations** (every secret update)
   - Who: Service Principal
   - What: Secret updated
   - When: Timestamp
   - Where: Key Vault diagnostic logs

4. **Terraform Operations** (every plan/apply)
   - Who: Service Principal
   - What: Resource changes
   - When: Timestamp
   - Where: Activity Log + App Configuration Activity Log

### How to View Audit Logs

```powershell
# Comprehensive view (use Monitor-TokenAudit.ps1 script)
.\Monitor-TokenAudit.ps1 -KeyVaultName "your-keyvault"

# Or manually in Azure Portal:

# 1. Service Principal Activity
# Azure Portal → Azure AD → Enterprise Applications
#   → (search for "sp-local-terraform-dev")
#   → Activity (see sign-in history)

# 2. Key Vault Secret Operations
# Azure Portal → Key Vault → Activity Log
#   → Filter by: Terraform-SP-* secrets

# 3. Terraform Changes
# Azure Portal → Resource Group → Activity Log
#   → Filter by: Principal = service principal ID

# 4. App Configuration Changes
# Azure Portal → App Configuration → Activity Log
#   → See all data changes made by SP
```

### For Compliance Reports

```powershell
# Export to CSV for compliance team
Get-AzActivityLog `
  -StartTime (Get-Date).AddDays(-30) `
  -ResourceGroupName "your-rg" | `
  Where-Object { $_.Caller -like "*terraform*" } | `
  Export-Csv -Path "terraform-audit-report.csv"
```

## Common Scenarios

### Scenario 1: First Time Setup

```bash
terraform init
terraform plan
terraform apply

# Save outputs, get client secret from Key Vault

# Now in PowerShell:
.\Ensure-FreshToken.ps1 -KeyVaultName "your-keyvault-name"

# Now you can run Terraform locally:
terraform plan
terraform apply
```

### Scenario 2: You're Away for Lunch

```bash
# Before lunch (10:00 AM)
.\Ensure-FreshToken.ps1  # Token is fresh

# Back from lunch (2:00 PM), more than 30 minutes later
.\Ensure-FreshToken.ps1  # Script refreshes token automatically

# Your Terraform commands work without issues
terraform plan
```

### Scenario 3: Service Principal Secret Is About to Expire

```bash
# Check when it expires
az keyvault secret show --name "Terraform-SP-ClientSecret" --vault-name "your-keyvault"

# Before expiration, regenerate:
terraform destroy  # Remove old SP
terraform apply    # Create new SP with new secret (1 year TTL)
```

### Scenario 4: Multiple Environments (Dev/Staging/Prod)

Create separate directories:

```bash
terraform-local-dev/
  ├─ terraform.tfvars  (environment = "dev")
  ├─ main.tf
  └─ Ensure-FreshToken.ps1

terraform-local-staging/
  ├─ terraform.tfvars  (environment = "staging")
  ├─ main.tf
  └─ Ensure-FreshToken.ps1

terraform-local-prod/
  ├─ terraform.tfvars  (environment = "prod")
  ├─ main.tf
  └─ Ensure-FreshToken.ps1

# Each has its own SP, secrets, and audit trail
```

## Troubleshooting

### "Get-AzKeyVaultSecret: Operation failed with status 403"

**Cause:** You don't have permission to read Key Vault secrets

**Solution:**
```bash
# Grant yourself access
az role assignment create \
  --assignee "your-user-id" \
  --role "Key Vault Secrets Officer" \
  --scope "/subscriptions/.../resourceGroups/.../providers/Microsoft.KeyVault/vaults/your-keyvault"
```

### "Invoke-RestMethod: (401) Unauthorized"

**Cause:** Service Principal credentials are invalid or secret expired

**Solution:**
```bash
# Regenerate the secret
terraform destroy -auto-approve
terraform apply -auto-approve

# Get new secret from Key Vault
az keyvault secret show --name "Terraform-SP-ClientSecret" --vault-name "your-keyvault"
```

### "terraform plan" fails with "Permission denied"

**Cause:** Service Principal doesn't have RBAC permission on the resource

**Solution:**
Check that the RBAC assignment was created:
```bash
# View SP's role assignments
az role assignment list \
  --assignee "your-sp-client-id" \
  --scope "/subscriptions/.../resourceGroups/.../providers/Microsoft.AppConfiguration/configurationStores/your-app-config"

# If missing, terraform apply again to create it
```

## Security Best Practices

✅ **Do:**
- Store client secret in Key Vault (never in code)
- Use Terraform state with remote backend (not local)
- Run token refresh before each operation
- Monitor audit logs regularly
- Rotate service principal secret annually (terraform handles this)

❌ **Don't:**
- Commit terraform.tfvars to git (contains secrets)
- Share client secret in Slack/email
- Leave token refresh script outputs visible
- Disable audit logging for compliance

## Customization

### Change Token Refresh Threshold

In `terraform.tfvars`:
```hcl
token_refresh_threshold_minutes = 45  # Refresh if >45 minutes old
```

### Add More RBAC Permissions

In `main.tf`, add more role assignments:
```hcl
resource "azurerm_role_assignment" "terraform_sp_storage" {
  scope              = "/subscriptions/.../resourceGroups/.../providers/Microsoft.Storage/storageAccounts/..."
  role_definition_name = "Storage Blob Data Contributor"
  principal_id       = azuread_service_principal.terraform_sp.object_id
}
```

Then: `terraform plan` and `terraform apply`

### Change Token Expiration

In `main.tf`, adjust `azuread_service_principal_password`:
```hcl
end_date_relative = "17520h"  # 2 years instead of 1
```

## Key Files Reference

### main.tf - What Gets Created

| Resource | Purpose |
|----------|---------|
| `azuread_application` | App registration for SP |
| `azuread_service_principal` | Actual service principal |
| `azuread_service_principal_password` | Credential (expires in 1 year) |
| `azurerm_key_vault_secret` (x5) | ClientId, ClientSecret, TenantId, AccessToken, RefreshTime |
| `azurerm_role_assignment` (x2) | App Config Data Owner + Key Vault access |
| `azurerm_log_analytics_workspace` | For audit logs (optional) |
| `azurerm_monitor_diagnostic_setting` (x2) | Logs for Key Vault and App Config |

### Ensure-FreshToken.ps1 - What It Does

| Step | Action |
|------|--------|
| 1 | Verify Azure authentication |
| 2 | Get SP credentials from Key Vault |
| 3 | Check if token is >30 minutes old |
| 4 | If yes: request fresh token from Azure AD |
| 5 | Store new token back in Key Vault (audit logged) |
| 6 | Export environment variables for Terraform |

### Monitor-TokenAudit.ps1 - What It Shows

| Check | Shows |
|-------|-------|
| 1 | Key Vault info and Terraform secrets |
| 2 | When token was last refreshed |
| 3 | Key Vault operation history |
| 4 | Service Principal activity |
| 5 | App Configuration changes |
| 6 | Compliance checklist |

## Support & Questions

For issues with:
- **Terraform syntax**: See main.tf comments
- **Token refresh**: Check Ensure-FreshToken.ps1 output
- **Audit logs**: Run Monitor-TokenAudit.ps1
- **Azure permissions**: Check RBAC assignments in Azure Portal

---

**Created with:** Terraform + PowerShell + Azure
**Compliance:** SOX5 ready (full audit trail)
**Tested with:** Terraform >= 1.0, Azure CLI 2.50+, PowerShell 7.0+
