# =============================================================================
# TERRAFORM: TOKEN REFRESH & AUDIT SOLUTION FOR LOCAL TERRAFORM RUNS
# =============================================================================
# This module sets up:
# 1. Service Principal for local Terraform (CLI use)
# 2. Token refresh automation (checks expiration, refreshes if needed)
# 3. Key Vault for credential storage (encrypted at rest)
# 4. Audit logging for compliance (who/what/when for every operation)
# 5. RBAC assignments scoped to specific resources
#
# Usage:
#   terraform init
#   terraform plan  (review before applying)
#   terraform apply
#
# After apply, you'll have credentials to use with `az login` locally
# =============================================================================

terraform {
  required_version = ">= 1.0"
  required_providers {
    azurerm = {
      source  = "hashicorp/azurerm"
      version = "~> 3.70"
    }
    azuread = {
      source  = "hashicorp/azuread"
      version = "~> 2.45"
    }
    random = {
      source  = "hashicorp/random"
      version = "~> 3.5"
    }
  }
}

provider "azurerm" {
  features {
    key_vault {
      purge_soft_delete_on_destroy    = false
      recover_soft_deleted_key_vaults = true
    }
  }
}

provider "azuread" {
  # Uses current Azure context
}

# =============================================================================
# VARIABLES - CUSTOMIZE FOR YOUR ENVIRONMENT
# =============================================================================

variable "environment" {
  description = "Environment name (dev, staging, prod)"
  type        = string
  default     = "dev"
}

variable "resource_group_name" {
  description = "Resource group for all resources"
  type        = string
}

variable "location" {
  description = "Azure region"
  type        = string
  default     = "eastus"
}

variable "app_config_name" {
  description = "Name of the App Configuration store (for RBAC scope)"
  type        = string
}

variable "key_vault_name" {
  description = "Name of Key Vault for storing credentials"
  type        = string
}

variable "allowed_user_principal_ids" {
  description = "User IDs that can access the Key Vault (for audit purposes)"
  type        = list(string)
  default     = []
}

variable "enable_audit_logging" {
  description = "Enable comprehensive audit logging to Log Analytics"
  type        = bool
  default     = true
}

variable "log_analytics_workspace_id" {
  description = "Log Analytics Workspace ID for audit logs (optional)"
  type        = string
  default     = ""
}

variable "token_refresh_threshold_minutes" {
  description = "Refresh token if it expires within this many minutes"
  type        = number
  default     = 30
}

# =============================================================================
# DATA SOURCES - Reference existing Azure resources
# =============================================================================

data "azurerm_client_config" "current" {}

data "azurerm_resource_group" "rg" {
  name = var.resource_group_name
}

data "azurerm_app_configuration" "appconfig" {
  name                = var.app_config_name
  resource_group_name = var.resource_group_name
}

data "azurerm_key_vault" "keyvault" {
  name                = var.key_vault_name
  resource_group_name = var.resource_group_name
}

# =============================================================================
# STEP 1: CREATE SERVICE PRINCIPAL FOR LOCAL TERRAFORM RUNS
# =============================================================================

resource "azuread_application" "terraform_sp" {
  display_name = "sp-local-terraform-${var.environment}"
  
  # Allow public client flows (for CLI use)
  public_client_enabled = true

  # Required for token requests
  required_resource_access {
    resource_app_id = "00000002-0000-0000-c000-000000000000"  # Azure AD Graph (legacy)

    resource_access {
      id   = "311a71cc-e848-46a1-bdf8-97ff7156d8e6"  # User.Read
      type = "Scope"
    }
  }
}

resource "azuread_service_principal" "terraform_sp" {
  application_id = azuread_application.terraform_sp.application_id
  use_existing   = false
}

# Generate credentials for the service principal
resource "azuread_service_principal_password" "terraform_sp" {
  service_principal_id = azuread_service_principal.terraform_sp.object_id
  display_name         = "Terraform Local Credential"
  end_date_relative    = "8760h"  # 1 year
}

# =============================================================================
# STEP 2: ASSIGN RBAC PERMISSIONS (scoped to App Configuration only)
# =============================================================================

resource "azurerm_role_assignment" "terraform_sp_appconfig" {
  scope              = data.azurerm_app_configuration.appconfig.id
  role_definition_name = "App Configuration Data Owner"
  principal_id       = azuread_service_principal.terraform_sp.object_id
}

# Allow Key Vault access for reading secrets (for token refresh script)
resource "azurerm_role_assignment" "terraform_sp_keyvault" {
  scope              = data.azurerm_key_vault.keyvault.id
  role_definition_name = "Key Vault Secrets Officer"
  principal_id       = azuread_service_principal.terraform_sp.object_id
}

# =============================================================================
# STEP 3: STORE CREDENTIALS IN KEY VAULT (encrypted at rest)
# =============================================================================

resource "azurerm_key_vault_secret" "sp_client_id" {
  name                = "Terraform-SP-ClientId"
  value               = azuread_service_principal.terraform_sp.application_id
  key_vault_id        = data.azurerm_key_vault.keyvault.id
  content_type        = "text/plain"
  expiration_date     = timeadd(timestamp(), "8760h")

  tags = {
    purpose = "terraform-local-runs"
    managed_by = "terraform"
    audit = "required"
  }

  lifecycle {
    ignore_changes = [expiration_date]
  }
}

resource "azurerm_key_vault_secret" "sp_client_secret" {
  name                = "Terraform-SP-ClientSecret"
  value               = azuread_service_principal_password.terraform_sp.value
  key_vault_id        = data.azurerm_key_vault.keyvault.id
  content_type        = "text/plain"
  expiration_date     = azuread_service_principal_password.terraform_sp.end_date
  
  tags = {
    purpose = "terraform-local-runs"
    managed_by = "terraform"
    audit = "required"
    sensitive = "true"
  }
}

resource "azurerm_key_vault_secret" "sp_tenant_id" {
  name                = "Terraform-SP-TenantId"
  value               = data.azurerm_client_config.current.tenant_id
  key_vault_id        = data.azurerm_key_vault.keyvault.id
  content_type        = "text/plain"

  tags = {
    purpose = "terraform-local-runs"
    managed_by = "terraform"
  }
}

# Token refresh timestamp (initialized to now)
resource "azurerm_key_vault_secret" "token_refresh_time" {
  name                = "Terraform-SP-TokenRefreshTime"
  value               = timestamp()
  key_vault_id        = data.azurerm_key_vault.keyvault.id
  content_type        = "text/plain"

  tags = {
    purpose = "token-refresh-tracking"
    managed_by = "terraform"
  }

  lifecycle {
    ignore_changes = [value]  # This gets updated by refresh script, not Terraform
  }
}

# Placeholder for access token (updated by refresh script)
resource "azurerm_key_vault_secret" "access_token" {
  name                = "Terraform-SP-AccessToken"
  value               = "placeholder"
  key_vault_id        = data.azurerm_key_vault.keyvault.id
  content_type        = "text/plain"

  tags = {
    purpose = "service-principal-token"
    managed_by = "terraform"
    sensitive = "true"
  }

  lifecycle {
    ignore_changes = [value]  # This gets updated by refresh script
  }
}

# =============================================================================
# STEP 4: KEY VAULT ACCESS POLICY FOR TOKEN REFRESH
# =============================================================================

# Allow the service principal itself to update tokens in Key Vault
resource "azurerm_key_vault_access_policy" "terraform_sp_self_update" {
  key_vault_id            = data.azurerm_key_vault.keyvault.id
  tenant_id               = data.azurerm_client_config.current.tenant_id
  object_id               = azuread_service_principal.terraform_sp.object_id

  secret_permissions = [
    "Get",      # Read token from KV
    "Set",      # Update token in KV
    "Update"    # Modify token
  ]
}

# Allow the current user to read credentials (for setup)
data "azurerm_client_config" "current_user" {}

resource "azurerm_key_vault_access_policy" "current_user" {
  key_vault_id            = data.azurerm_key_vault.keyvault.id
  tenant_id               = data.azurerm_client_config.current.tenant_id
  object_id               = data.azurerm_client_config.current.object_id

  secret_permissions = [
    "Get",
    "List"
  ]
}

# =============================================================================
# STEP 5: AUDIT LOGGING - TRACK ALL OPERATIONS
# =============================================================================

# Create Log Analytics Workspace for audit logs (if not provided)
resource "azurerm_log_analytics_workspace" "audit" {
  count = var.enable_audit_logging && var.log_analytics_workspace_id == "" ? 1 : 0
  
  name                = "law-terraform-audit-${var.environment}"
  location            = var.location
  resource_group_name = var.resource_group_name
  sku                 = "PerGB2018"
  retention_in_days   = 90  # SOX5 compliance: retain for audit

  tags = {
    purpose = "terraform-audit-logs"
    compliance = "sox5"
  }
}

# Enable diagnostic logging on Key Vault (audit all secret operations)
resource "azurerm_monitor_diagnostic_setting" "keyvault_audit" {
  count = var.enable_audit_logging ? 1 : 0
  
  name                       = "keyvault-audit-logs"
  target_resource_id         = data.azurerm_key_vault.keyvault.id
  log_analytics_workspace_id = var.log_analytics_workspace_id != "" ? var.log_analytics_workspace_id : azurerm_log_analytics_workspace.audit[0].id

  enabled_log {
    category = "AuditEvent"
    enabled  = true
  }

  metric {
    category = "AllMetrics"
    enabled  = false
  }
}

# Enable diagnostic logging on App Configuration (audit all data changes)
resource "azurerm_monitor_diagnostic_setting" "appconfig_audit" {
  count = var.enable_audit_logging ? 1 : 0
  
  name                       = "appconfig-audit-logs"
  target_resource_id         = data.azurerm_app_configuration.appconfig.id
  log_analytics_workspace_id = var.log_analytics_workspace_id != "" ? var.log_analytics_workspace_id : azurerm_log_analytics_workspace.audit[0].id

  enabled_log {
    category = "HttpRequest"
    enabled  = true
  }

  enabled_log {
    category = "Audit"
    enabled  = true
  }
}

# =============================================================================
# STEP 6: TAGS FOR COMPLIANCE & AUDIT TRAIL
# =============================================================================

locals {
  common_tags = {
    environment         = var.environment
    purpose             = "terraform-local-runs"
    created_by          = "terraform"
    compliance_level    = "sox5"
    audit_required      = "true"
    token_refresh       = "enabled"
    refresh_threshold   = "${var.token_refresh_threshold_minutes} minutes"
  }
}

# =============================================================================
# OUTPUTS - USE THESE FOR YOUR LOCAL TERRAFORM SETUP
# =============================================================================

output "service_principal_client_id" {
  description = "Service Principal Client ID (for az login)"
  value       = azuread_service_principal.terraform_sp.application_id
  sensitive   = false
}

output "service_principal_tenant_id" {
  description = "Tenant ID"
  value       = data.azurerm_client_config.current.tenant_id
  sensitive   = false
}

output "key_vault_name" {
  description = "Key Vault name (where secrets are stored)"
  value       = data.azurerm_key_vault.keyvault.name
  sensitive   = false
}

output "key_vault_url" {
  description = "Key Vault URL (for secret retrieval)"
  value       = data.azurerm_key_vault.keyvault.vault_uri
  sensitive   = false
}

output "terraform_sp_object_id" {
  description = "Service Principal Object ID (for RBAC assignments)"
  value       = azuread_service_principal.terraform_sp.object_id
  sensitive   = false
}

output "setup_instructions" {
  description = "Instructions for using this locally"
  value = <<-EOT
    
    ============================================
    LOCAL TERRAFORM SETUP INSTRUCTIONS
    ============================================
    
    1. Save the service principal credentials:
       - Client ID: ${azuread_service_principal.terraform_sp.application_id}
       - Tenant ID: ${data.azurerm_client_config.current.tenant_id}
       - Client Secret: (retrieve from Key Vault secret: Terraform-SP-ClientSecret)
    
    2. Authenticate using az CLI:
       az login --service-principal \
         -u ${azuread_service_principal.terraform_sp.application_id} \
         -p (your-secret) \
         --tenant ${data.azurerm_client_config.current.tenant_id}
    
    3. Run Terraform locally:
       terraform init
       terraform plan
       terraform apply
    
    4. Set up token refresh script (see token-refresh-script.ps1):
       - Runs automatically before Terraform operations
       - Checks token expiration (${var.token_refresh_threshold_minutes} min threshold)
       - Refreshes token if needed
       - Stores in Key Vault with audit trail
    
    5. Monitor token operations:
       - Check Azure Activity Log for service principal logins
       - Check Key Vault audit logs for secret updates
       - Check App Configuration Activity Log for data changes
       - All operations are timestamped and tied to this SP
    
    Key Vault: ${data.azurerm_key_vault.keyvault.name}
    Audit Logs: ${var.enable_audit_logging ? "Enabled (Log Analytics)" : "Disabled"}
    
  EOT
  sensitive = false
}

output "audit_configuration" {
  description = "Audit logging configuration"
  value = {
    enabled                      = var.enable_audit_logging
    log_analytics_workspace_name = var.enable_audit_logging && var.log_analytics_workspace_id == "" ? azurerm_log_analytics_workspace.audit[0].name : var.log_analytics_workspace_id
    retention_days               = 90
    monitored_resources = [
      "Key Vault (all secret operations)",
      "App Configuration (all data operations)",
      "Service Principal (authentication logs)"
    ]
  }
  sensitive = false
}
